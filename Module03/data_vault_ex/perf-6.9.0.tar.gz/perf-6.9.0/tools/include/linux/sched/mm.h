#ifndef _TOOLS_PERF_LINUX_SCHED_MM_H
#define _TOOLS_PERF_LINUX_SCHED_MM_H

#define might_alloc(gfp)	do { } while (0)

#endif  /* _TOOLS_PERF_LINUX_SCHED_MM_H */
